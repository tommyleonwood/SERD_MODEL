﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace serd
{
    class program
    {
        static int[] systemEv(double pd, double pr, int TS, int iterations1)
        {

            int[] totetEv = new int[TS];
            double pt;
            pt=pd+pr;
            int St;
            int et;

            bool merged;
            var random = new Random();
            for(int i3=0; i3 < iterations1; i3++)
            {
            int[] IEProp = new int[2];
            IEProp[0] = 0;
            IEProp[1] = 0;
            merged = false;
            St = 1;
            et = St;
                for(int i1=0; i1<TS; i1++)
                {
                    int shift = 0;
                    int StDiff=0;
                    int[] actionsArray = new int[St];
                    if(merged==false)
                    {
                        for(int i2=0;i2<St;i2++)
                        {
                            double rand = random.NextDouble();
                            if(rand<pd)
                            {
                                actionsArray[i2] = 1;
                                StDiff+=1;
                            }
                            else
                            {
                                if(rand<pt)
                                {
                                    actionsArray[i2] = -1;
                                    StDiff-=1;
                                }
                                else
                                {
                                    actionsArray[i2] = 0;
                                }
                            }
                        }
                        int St2=St+StDiff;
                        if(St2==0){merged=true;}
                        if(merged==false)
                        {
                        int[] IEProp2 = new int[St2+1];
                        for(int i2=0;i2<St;i2++)
                        {
                            if(actionsArray[i2]==1)
                            {
                                IEProp2[i2+shift]=IEProp[i2]+1;
                                IEProp2[i2+shift+1]=0;
                                shift+=1;
                            }
                            else
                            {
                                if(actionsArray[i2]==-1)
                                {
                                    IEProp2[i2+shift]+=IEProp[i2+1]-1;
                                    shift-=1;
                                }
                                else
                                {
                                    IEProp2[i2+shift]=IEProp[i2];
                                }
                            }
                        }
                                
                        et+=IEProp2[0];
                        int[] IEProp3 = new int[St2+1];

                        for(int i2=0;i2<St2;i2++){IEProp3[i2]=IEProp2[i2+1];}
                        IEProp3[St2]=0;
                        IEProp=IEProp3;
                        St=St2;

                        }
                        else
                        {
                            St=1;
                            et=St;
                            int[] IEProp4 = new int[2];
                        IEProp4[0] = 0;
                        IEProp4[1] = 0;
                        IEProp=IEProp4;
                        merged = false;
                        }



                        if(i3==0)
                        {
                        totetEv[i1]=et;
                        }
                        else
                        {
                        totetEv[i1]+=et;
                        }
                        
                    }
                }
            }
        return totetEv;
        }

        static void Main(string[] args)
        {
        int TS=1000;
        int iterations1=100000;
        double pd = 0.3333333333333f;
        double pr = 0.3333333333333f;

        double[] systEvExp= new double[iterations1];
            int[] systEv=systemEv(pd, pr, TS, iterations1);

            string systEvToString = "{";

            for(int i2=0;i2<TS;i2++)
            {  
                if(i2==0)
                {
                systEvToString = systEvToString + systEv[i2].ToString();       
                }
                else
                {
                if(i2<TS-1)
                {
                systEvToString = systEvToString + "," + systEv[i2].ToString();
                }
                else
                {
                systEvToString = systEvToString + "," + systEv[i2].ToString() + "}";
                }
                }
            }
            writeDatatoCSV(systEvToString, "TestA1.txt");
        }

        static void writeDatatoCSV(String etStr, String filepath)
            {
                try
                {
                    using(System.IO.StreamWriter file = new System.IO.StreamWriter(@filepath,true))
                    {
                        file.WriteLine(etStr);
                    }
                }
                catch(Exception ex)
                {
                throw new ApplicationException("Error :", ex);
                }
            }
        static void writeDelDatatoCSV(String etStr, String filepath)
            {
                try
                {
                    using(System.IO.StreamWriter file = new System.IO.StreamWriter(@filepath,false))
                    {
                        file.WriteLine(etStr);
                    }
                }
                catch(Exception ex)
                {
                throw new ApplicationException("Error :", ex);
                }
            }
            
    }
}




    
